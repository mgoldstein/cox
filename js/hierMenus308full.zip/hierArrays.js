arMenu1 = new Array(
120,
200,"",
"","",
"#3399FF","#55BBFF",
"#0000FF","#000088",
"Experts","http://www.webreference.com/experts/",1,
"Contents","http://www.webreference.com/index2.html",0,
"Services","http://www.webreference.com/index2.html",0,
"About","http://www.webreference.com/about.html",0
)

arMenu1_1 = new Array(
"3-D Animation","http://www.webreference.com/3d/",0,
"Design","http://www.webreference.com/dlab/",0,
"DHTML","http://www.webreference.com/dhtml/",1,
"Internet","http://www.webreference.com/outlook/",0,
"JavaScript","http://www.webreference.com/js/",0
)

arMenu1_1_3 = new Array(
"Columns","http://www.webreference.com/dhtml/",0,
"Diner","http://www.webreference.com/dhtml/diner/",0,
"Dynomat","http://www.webreference.com/dhtml/dynomat/",0
)

arMenu2 = new Array(
175,
150,300,
"black","white",
"#2D9B83","#4BB9A1",
"black","black",
"Experts","http://www.webreference.com/experts/",1,
"Contents","http://www.webreference.com/index2.html",0
)

arMenu2_1 = new Array(
"3-D Animation","http://www.webreference.com/3d/",0,
"Design","http://www.webreference.com/dlab/",0,
"DHTML","http://www.webreference.com/dhtml/",0,
"Internet","http://www.webreference.com/outlook/",0,
"JavaScript","http://www.webreference.com/js/",0
)

arMenu3 = new Array(
"",
"","",
"","",
"","",
"","",
"Experts","http://www.webreference.com/experts/",0,
"Contents","http://www.webreference.com/index2.html",1
)

arMenu3_2 = new Array(
"Features","http://www.webreference.com/articles.html",0,
"Forum","http://www.webreference.com/cgi-bin/Ultimate.cgi?action=intro",0,
"How-to","http://www.webreference.com/dev/",0,
"New","http://www.webreference.com/headlines/",0,
"Hot Sites","http://www.webreference.com/hot/",0
)

arMenu4 = new Array(
168,
"","",
"black","white",
"#F84130","#FF5F4E",
"#9A0E20","white",
"Experts","http://www.webreference.com/experts/",0,
"Services","http://www.webreference.com/index2.html",1
)

arMenu4_2 = new Array(
"Domains","http://www.webreference.com/services/dns/",0,
"Graphics","http://www.webreference.com/services/gw/",0,
"Jobs","http://www.webreference.com/jobs/",0,
"Reference","http://www.webreference.com/services/reference/",0,
"ROADMAP","http://www.webreference.com/roadmap/",0,
"Search","http://www.webreference.com/cgi-bin/search.cgi",0,
"Validation","http://www.webreference.com/services/validation/",0,
"Cool Sites","http://www.coolcentral.com",0
)
