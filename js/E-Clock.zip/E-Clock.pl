#!/usr/local/bin/perl

# Erosic Web Services
# Script: E-Clock
# Version: 2.0
# Date: 13 Oct 2000
# Author: eric418 (4w1r8@i.am)
# WebSite: http://erosic.uhome.net
#
# Copyright (c) 2000 Erosic Web Services. All rights reserved.
# Permission given to use the script provided that this notice remains as is.
#
# To execute the script, add this to your page:
# <!--#include virtual="path/to/E-Clock.pl?Style=1&Zone=+8&Date=1&Time=1&Itime=1"-->
#
# - Style should be within 1 to 6
# - Zone can be either + or - hours different from GMT time
# - Date should be either 1 or 0 (for displaying Date or NOT)
# - Time should be either 1 or 0 (for displaying Time or NOT)
# - Itime should be either 1 or 0 (for displaying Itime or NOT)
#
################################################################

($STYLE, $ZONE, $DATE, $TIME, $ITIME) = split(/&/, $ENV{QUERY_STRING});
($Style, $style) = split(/=/, $STYLE);
($Zone, $zone) = split(/=/, $ZONE);
($Date, $date) = split(/=/, $DATE);
($Time, $time) = split(/=/, $TIME);
($Itime, $itime) = split(/=/, $ITIME);
$timezone = $zone * 3600;

@days = ('Sun','Mon','Tue','Wed','Thu','Fri','Sat');
@months = ('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');

($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = gmtime(time+$timezone);
($asec,$amin,$ahour,$aday,$amon,$ayear,$awday,$ayday,$aisdst) = gmtime(time);

if($hour < 10) { $hour = "0$hour"; }
if ($min < 10) { $min = "0$min"; }
if ($sec < 10) { $sec = "0$sec"; }
$saveyear = ($year % 100);
$year = 1900 + $year;

if($date eq 1){
$date = "$days[$wday], $mday $months[$mon], $year.";}
elsif($date eq 0){
$date = "";}
else{
print "Content-type: text/html\n\n";
print qq~
<html><head><title>Erosic Web Services</title>
</head>
<body background=../share/water.gif>
<font face=arial>Date should be either <b>1</b> or <b>2</b>
<br><font size=1 face=arial>powered by <a href=http://erosic.uhome.net target=_blank>Erosic Web Services</a>.</body></html>
~;
exit;
}

if($time eq 1){
$time = "$hour:$min:$sec";}
elsif($time eq 0){
$time = "";}
else{
print "Content-type: text/html\n\n";
print qq~
<html><head><title>Erosic Web Services</title>
</head>
<body background=../share/water.gif>
<font face=arial>Time should be either <b>1</b> or <b>2</b>
<br><font size=1 face=arial>powered by <a href=http://erosic.uhome.net target=_blank>Erosic Web Services</a>.</body></html>
~;
exit;
}

if($itime eq 1){
$itime = "\@" . int(($ahour * 3600 + $amin * 60 + $asec)*5 /432);}
else{
$itime = "";}

print "Content-type: text/html\n\n";
print qq~
<html><head><title>Erosic Web Services</title>
</head>
~;

if($style eq '1'){
print qq~
<body background=../share/water.gif><input type=text size=35 value='$date $time $itime' style='font-family: Arial; font-size: 10pt'>
~;}

elsif($style eq '2'){
print qq~
<body background=../share/water.gif onload='Type();'>
<script language=JavaScript>
var msg="$date $time $itime";
var interval = 100;
seq = 0;
function Type() {
document.tmForm.tmText.value = msg.substring(0, seq+1);
seq++;
if ( seq >= msg.length ) { seq = 0 };
window.setTimeout("Type();", interval );
} 
</script>
<form name=tmForm><input type=text size=35 name=tmText style='font-family: Arial; font-size: 10pt'>
~;}

elsif($style eq '3'){
print qq~
<body background=../share/water.gif onload='Scroll();'>
<script language="JavaScript">
var msg=" $date $time $itime ";
var interval = 200;
var space10="";
var seq=0;

function Scroll() {
document.tmForm.tmText.value = msg.substring(seq, msg.length) + space10 + msg.substring(0, msg.length);
seq++;seq++;
if ( seq > msg.length ) { seq = 0 };
window.setTimeout("Scroll();", interval );
}
</script>
<form name="tmForm"><input type="text" size="35" name="tmText" style="font-family: Arial; font-size: 10pt">
~;}

elsif($style eq '4'){
print qq~
<body background=../share/water.gif>
<textarea rows=3 cols=25 style='font-family: Arial; font-size: 10pt'>$date\n$time\n$itime</textarea>
~;}

elsif($style eq '5'){
print qq~
<body background=../share/water.gif>
<select style='font-family: Arial; font-size: 10pt'>
<option>$date</option>
<option>$time</option>
<option>$itime</option>
</select>
~;}

elsif($style eq '6'){
print qq~
<body background=../share/water.gif>
<font face=arial>$date $time $itime
~;}

else{
print qq~
<body background=../share/water.gif>
<font face=arial>Style should be within <b>1</b> to <b>6</b>
~;}

print qq~
<br><font size=1 face=arial>powered by <a href=http://erosic.uhome.net target=_blank>Erosic Web Services</a>.</body></html>
~;